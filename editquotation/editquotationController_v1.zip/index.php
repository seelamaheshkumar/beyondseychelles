<?php include("../layouts/header.php"); ?>
<main id="main" class="main">
<div class="pagetitle row">
    <div class="col-md-9">
    <h1>Update Quotation</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="../dashboard">Dashboard</a></li>
            <li class="breadcrumb-item active">New Quotation</li>
        </ol>
    </nav>
</div>
<div class="col-md-3" style="text-align:right">
    <a href='../quotations' class='btn btn-info'>
        <i class="ri-user-add-fill"></i> Back to Quotations
    </a>
</div>
</div>
    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <form id="frmquote" action="" method="POST">
                        <div class="card-body">
                            <div class="table-responsive">
                                <br>
                                <table class="table">
                                    <tr>
                                        <td>Company Name </td>
                                        <td><input type="text" name="company_name" id="company_name" class="form-control" required /></td>
                                        <td>&nbsp;&nbsp;</td>
                                        <td>Contact Person </td>
                                        <td><input type="text" name="contact_person" id="contact_person" class="form-control" required /></td>
                                    </tr>
                                    <tr>
                                        <td>Contact No </td>
                                        <td><input type="text" name="contact_no" id="contact_no" class="form-control" required /></td>
                                        <td>&nbsp;&nbsp;</td>
                                        <td>Remarks </td>
                                        <td><textarea name="address" id="address" rows=3 cols=35 class="form-control" required></textarea></td>
                                    </tr>
                                </table>
                                <table class="table">
                                    <tr>
                                        <td>
                                           <h4>List of Products</h4>
                                        </td>
                                        <td align="right">
                                          <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">
                                              <i class="ri-user-add-fill"></i> Add Product 
                                          </button>
                                        </td>
                                    </tr>
                                </table>
                                
                                <div class="table-responsive" id="showUsers">
                                    <h3 class="text-center text-success" style="margin-top: 150px">Loading...</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12" style="text-align:right">
                            <table class="table">
                                <tr>
                                    <td>Total Qty </td>
                                    <td><input type="text" name="tqty" id="tqty" class="form-control" required style="float:right; text-align:right;" readonly /></td>
                                    <td>&nbsp;&nbsp; </td>
                                    <td>Total Value </td>
                                    <td><input type="text" name="qvalue" id="qvalue" class="form-control" required  style="float:right; text-align:right;" readonly /></td>
                                </tr>                                
                            </table>
                            <input type="hidden" name="main_qid" id="main_qid" value="" />
                            <button type="submit" id="btnSaveQuotation" class="btn btn-success"><i class="ri-user-add-fill"></i> Update Quotation </button><br><br>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Add New Product Modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addModalLabel">Add New Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="add-user-form">
                <input type="hidden" id="modal_qid" name="qid" value="">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="add_pname">Product Name</label>
                        <input type="text" class="form-control" id="add_pname" name="product_name" required>
                    </div>
                    <div class="form-group">
                        <label for="add_pqty">Qty</label>
                        <input type="number" class="form-control" id="add_pqty" name="qty" required>
                    </div>
                    <div class="form-group">
                        <label for="add_unitcost">Unit Cost</label>
                        <input type="number" step="0.01" class="form-control" id="add_unitcost" name="unitcost" required>
                    </div>
                    <div class="form-group">
                        <label for="add_amount">Amount</label>
                        <input type="text" class="form-control" id="add_amount" name="amount" readonly>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Update Product Modal -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Update Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="frmustatus">
                <input type="hidden" id="edit_pid" name="pid1">
                <input type="hidden" id="edit_qid" name="edit_qid">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="edit_pname">Product Name</label>
                        <input type="text" class="form-control" id="edit_pname" name="pname" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_pqty">Qty</label>
                        <input type="number" class="form-control" id="edit_pqty" name="pqty" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_ucost">Unit Cost</label>
                        <input type="number" step="0.01" class="form-control" id="edit_ucost" name="ucost" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_tot1">Total</label>
                        <input type="text" class="form-control" id="edit_tot1" name="tot1" readonly>
                    </div>                            
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include("../layouts/footer.php"); ?>
<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<script src="scripts.js"></script>
