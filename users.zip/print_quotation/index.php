<?php
require_once('../pdf/tcpdf.php');
require_once '../quotations/quotationsModel.php';
$customersModel = new UsersModel();

class PDF extends TCPDF
{
    public $isLastPage = false;

    // Page header
    public function Header()
    {
        // Logo
        $imageFile = K_PATH_IMAGES.'topbg.jpg';
        $this->Image($imageFile, 0, 0, 210, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);
        
        // Set font
        $this->SetFont('helvetica', 'B', 16);

        // Line break
        $this->Ln(15);
    }

    // Page footer
    public function Footer()
    {
        // Only display footer on the last page
        if ($this->isLastPage) {
            // Position at 15 mm from bottom
            $this->SetY(-55);

            // Set font
            $this->SetFont('helvetica', 'B', 12);
            $this->Cell(190, 10, 'Bank Details', 0, false, 'L', 0, '', 0, false, 'T', 'M');
            $this->Ln(10);
            $this->SetFont('helvetica', '', 10);
            $this->Cell(185, 5, "Acc Name: BEYOND DESIGN", 0, 1, 'L');
            $this->Cell(185, 5, "Acc No: 010 1021858", 0, 1, 'L');
            $this->Cell(185, 5, "IBAN: SC96BARC01010000000101021858SCR", 0, 1, 'L');
            $this->Cell(185, 5, "SWIFT CODE: BARCSCSC", 0, 1, 'L');
            $this->Cell(185, 5, "Bank Name: ABSA", 0, 1, 'L');
            $this->SetFont('helvetica', 'B', 12);
            $this->Cell(190, 10, 'THANK YOU', 0, false, 'C', 0, '', 0, false, 'T', 'M');
        }
    }
}

// Create PDF object
$pdf = new PDF();
// Set document properties
$pdf->SetCreator('S Mahesh Kumazr');
$pdf->SetAuthor('Credge Technologies');
$pdf->SetTitle('Quotation');
$repValue = isset($_GET['Rep']) ? $_GET['Rep'] : 0;

// Add a page
$pdf->AddPage();
$quotation = $customersModel->getQuotationByID($repValue);
$products = $customersModel->getQuotationProductsByID($repValue);
if ($quotation) {
    $qdate = date('d-M-Y', strtotime($quotation['qdate']));
    //$qid = $quotation['qid'] . '/' . date('Y');
    $qid = $quotation['qno'] ;
    $pdf->Ln(50);
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(185, 8, "Quotation No # : " . $qid, 0, 1, 'R');
    $pdf->Cell(185, 8, "TIN # : 352 891 692", 0, 1, 'R');
    $pdf->Cell(185, 8, "Date # : " . $qdate, 0, 1, 'R');
    
    $pdf->Cell(185, 8, "CUSTOMER", 0, 1, 'L');
    $pdf->SetFont('helvetica', '', 11);
    $pdf->Cell(33, 8, "Company Name", 0, 0, 'L');
    $pdf->Cell(157, 8, ": " . $quotation['company_name'], 0, 0, 'L');
    $pdf->Ln(5);
    $pdf->Cell(33, 8, "Contact Name", 0, 0, 'L');
    $pdf->Cell(157, 8, ": " . $quotation['contact_person'], 0, 0, 'L');
    $pdf->Ln(5);
    $pdf->Cell(33, 8, "Contact No", 0, 0, 'L');
    $pdf->Cell(157, 8, ": " . $quotation['contact_no'], 0, 0, 'L');
    $pdf->Ln(5);
    $pdf->Cell(33, 8, "Remarks", 0, 0, 'L');
    $pdf->Cell(157, 8, ": " . $quotation['address'], 0, 0, 'L');
    $pdf->Ln(15);
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(15, 8, "SL No", 1, 0);
    $pdf->Cell(85, 8, "Description", 1, 0);
    $pdf->Cell(25, 8, "Qty", 1, 0, 'C');
    $pdf->Cell(25, 8, "Unit Cost", 1, 0, 'C');
    $pdf->Cell(40, 8, "Amount", 1, 1, 'C');
    $pdf->SetFont('helvetica', '', 12);
    $slno = 1;
    if (!empty($products)) {
        foreach ($products as $product) {
            $maxLines = max(
                getNumLines($pdf, 85, $product['product_name']),
                getNumLines($pdf, 30, $product['qty']),
                getNumLines($pdf, 30, $product['unitcost']),
                getNumLines($pdf, 30, $product['total'])
            );
            $lineHeight = 8;
            $cellHeight = $maxLines * $lineHeight;
            $pdf->Cell(15, $cellHeight, $slno++, 'LTRB', 0, 'C');
            $productName = $product['product_name'];
            $pdf->MultiCell(85, $cellHeight, $productName, 'LTRB', 'L', 0, 0);
            $pdf->Cell(25, $cellHeight, $product['qty'], 'LTRB', 0, 'C');
            $pdf->Cell(25, $cellHeight, number_format($product['unitcost'], 2), 'LTRB', 0, 'C');
            $pdf->Cell(40, $cellHeight, number_format($product['total'], 2), 'LTRB', 1, 'R');

            // Check if the next item will fit on the current page, if not, add a new page
            if ($pdf->GetY() + $cellHeight + 55 > $pdf->getPageHeight()) {
                $pdf->AddPage();
                $pdf->ln(50);
            }
        }
        $pdf->Cell(150, 8, "Sub Total", 0, 0, 'R');
        $pdf->Cell(40, 8, number_format($quotation['qvalue'], 2), 'LTRB', 1, 'R');
        $pdf->Cell(150, 8, "VAT 15%", 0, 0, 'R');
        $vat = $quotation['qvalue'] * 15 / 100;
        $pdf->Cell(40, 8, number_format($vat, 2), 'LTRB', 1, 'R');
        $pdf->Cell(150, 8, "TOTAL", 0, 0, 'R');
        $total = $vat + $quotation['qvalue'];
        $pdf->Cell(40, 8, number_format($total, 2), 'LTRB', 1, 'R');
    }
    $pdf->isLastPage = true;
}

// Close and output PDF document
$pdf->Output('Quotation.pdf', 'I');

function getNumLines($pdf, $width, $text)
{
    return $pdf->getNumLines($text, $width);
}

function truncateText($text, $maxLength)
{
    if (strlen($text) > $maxLength) {
        return substr($text, 0, $maxLength - 3) . '...';
    }
    return $text;
}
?>
